package atm_project.atm;

public final class ChaseExternal extends AbstractChase{
    public ChaseExternal() {
        super(2000);
    }
}
