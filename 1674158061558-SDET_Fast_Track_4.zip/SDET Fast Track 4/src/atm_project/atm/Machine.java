package atm_project.atm;

public interface Machine {
    void turnOn();
    void turnOff();
}
