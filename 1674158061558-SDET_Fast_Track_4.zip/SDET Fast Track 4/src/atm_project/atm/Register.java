package atm_project.atm;

public interface Register {
    boolean createAccount(String name, int pin, double deposit);
}
