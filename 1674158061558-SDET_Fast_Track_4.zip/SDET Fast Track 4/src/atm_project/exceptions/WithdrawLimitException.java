package atm_project.exceptions;

public class WithdrawLimitException extends RuntimeException{
}
