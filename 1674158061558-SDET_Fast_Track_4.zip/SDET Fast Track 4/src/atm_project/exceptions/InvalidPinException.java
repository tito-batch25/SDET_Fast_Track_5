package atm_project.exceptions;

public class InvalidPinException extends RuntimeException{
}
