package atm_project.exceptions;

public class PowerNotFoundException extends RuntimeException{

}
