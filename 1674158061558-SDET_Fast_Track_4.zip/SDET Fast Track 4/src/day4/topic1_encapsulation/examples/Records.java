package day4.topic1_encapsulation.examples;

public class Records { // normal encapsulation
    private String info;

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
