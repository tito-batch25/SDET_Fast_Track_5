package day4.topic2_abstraction.apps;

public interface Stories {
    double lengthLimit = 3; // public static final LENGTH_LIMIT
    public abstract void createStory(); // public abstract
    void viewStory(); // public abstract
}
