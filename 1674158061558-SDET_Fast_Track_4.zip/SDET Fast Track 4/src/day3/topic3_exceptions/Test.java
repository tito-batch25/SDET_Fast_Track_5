package day3.topic3_exceptions;

import day3.topic2_inheritance.Animal;
import day3.topic2_inheritance.Lion;

public class Test extends Animal {
    public static void main(String[] args) {
//     new Test().d
    }
}
