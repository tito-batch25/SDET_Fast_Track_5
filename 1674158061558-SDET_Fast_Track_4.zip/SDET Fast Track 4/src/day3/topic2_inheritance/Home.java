package day3.topic2_inheritance;

public class Home {
    String location;
}
