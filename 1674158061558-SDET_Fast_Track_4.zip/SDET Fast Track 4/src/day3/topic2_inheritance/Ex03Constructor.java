package day3.topic2_inheritance;

public class Ex03Constructor extends Object{

    // constructors are not inherited, but they can be called
    public Ex03Constructor() {
        super();
    }

    public static void main(String[] args) {
//        Jacket jacket = new Jacket();
    }

}
