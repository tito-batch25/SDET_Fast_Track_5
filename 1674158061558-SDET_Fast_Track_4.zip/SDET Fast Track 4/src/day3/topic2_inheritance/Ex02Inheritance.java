package day3.topic2_inheritance;

public class Ex02Inheritance {
    public static void main(String[] args) {

        Lion lion1 = new Lion();
        //lion1.??   what can the lion object access?

        //Lion is a Animal
        //Lion has a Home

    }
}
