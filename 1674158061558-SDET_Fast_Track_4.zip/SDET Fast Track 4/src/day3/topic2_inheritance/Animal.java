package day3.topic2_inheritance;

public class Animal{
    String species;
    long population;

    public int a;
    protected int b;
    int c;
    private int d;

    void eat(){
        System.out.println(species + " is eating");
    }
}
