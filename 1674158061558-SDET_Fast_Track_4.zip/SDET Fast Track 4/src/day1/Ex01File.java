package day1;

import java.util.Arrays;
import java.util.Scanner;
import java.util.*;
import java.lang.*;

public class Ex01File {

}


/*
    PIC

    File name: Ex01File.java same as public class name Ex01File

    There can be other classes defined in this file, but they cannot be public
 */